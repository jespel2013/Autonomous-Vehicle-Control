//----------------------------------------------------------------------//
// Author:
// Net ID:
// Date:
//
//----------------------------------------------------------------------//

#include "CarSimulator.h"
#include <limits>

using namespace std;

/**
 * Creates CarSimulator object
 *
 * @requirement assigns _inputFileName to object data members _inputFileName
 * @requirement assigns _outputFileName to object data members _outputFileName
 */
CarSimulator::CarSimulator(std::string inputFileName, std::string outputFileName){
	
	_inputFileName = inputFileName;
	_outputFileName = outputFileName;
}

/**
 * Populates object _commands data member from _inputFileName
 *
 * @requirement if the Command IsValid() returns false for any Command, the input file is invalidated. An output file still needs to be generated
 * @requirement if a line is not formatted correctly, the file is not invalidated. It is just discarded.
 * @requirement close the file at the end of the function

 input: timestamp, velocity, rate
 */
void CarSimulator::ReadCommandsFromFile(){

	std::ifstream fileInput;
	fileInput.open(_inputFileName);
	if (!fileInput.is_open()) {
		cout << "File could not be read" << endl;
		return;
	}

	double timestamp;
	double velocity;
	double angleRate;

	Command currentCommand;


	while (!fileInput.eof()) {
		fileInput >> timestamp >> velocity >> angleRate;


		currentCommand.SetTimeStamp(timestamp);
		currentCommand.SetVelocity(velocity);
		currentCommand.SetTireAngleRate(angleRate);

		if (!currentCommand.IsValid()) {
			_commands.clear();
			_stateHistory.clear();
			fileInput.close();
		}
		else {
			_commands.push_back(currentCommand);
		}

	}

	fileInput.close();
	return;

}

/**
 * Populates _stateHistory data member from already populated _commands by calling RunCommand on each command
 *
 * @requirement the last Command in _commands has a duration of .2 seconds
 * @requirement the calculated duration between each Command must be >= .005 seconds and <= .2 seconds otherwise, the whole set of _commands is invalidated. An output file should still be generated.
 */
void CarSimulator::RunAllCommands(){

	double duration;

	for (unsigned int i = 0; i < _commands.size(); i++) {
		if (i == _commands.size() - 1) {
			duration = 0.2;
		}
		else {
			duration = _commands[i + 1].GetTimeStamp() - _commands[i].GetTimeStamp();
		}
		if (duration >= 0.005 && duration <= 0.20) {
			RunCommand(_commands[i], duration);
		}
		else {
			if (duration > 0.20) {
				_stateHistory.clear();
				_commands.clear();
				if (duration < .005) {
					_stateHistory.clear();
					_commands.clear();
				}
			}
		}
	}



	return;

}

/**
 * Adds a new State to _stateHistory given a Command and duration
 *
 * @requirement A new state is updated according to the following equations/pseudocode:
 *
 * x_pos = x_prev + duration*velocity*cos(tire_angle)*cos(heading)
 * y_pos = y_prev + duration*velocity*cos(tire_angle)*sin(heading)
 * tire_angle = tire_angle_prev + duration*tire_angle_rate
 * heading = heading_prev + duration*velocity*(1.0/L)*sin(tire_angle)
 * time_stamp = time_stamp_prev + duration
 *
 * @requirement all data members of the new State must be set with setters. Otherwise, bad things will happen.
 */
void CarSimulator::RunCommand( Command command, double duration ){


	double xPos, yPos, tireAngle, heading, timeStamp;

	State oldState = GetCurrentState();

	//equations
	xPos = oldState.GetXPos() + duration * command.GetVelocity() * cos(oldState.GetTireAngle()) * cos(oldState.GetHeading());
	yPos = oldState.GetYPos() + duration * command.GetVelocity() * cos(oldState.GetTireAngle()) * sin(oldState.GetHeading());
	tireAngle = oldState.GetTireAngle() + duration * command.GetTireAngleRate();
	heading = oldState.GetHeading() + duration * command.GetVelocity() * (1.0 / L) *sin(oldState.GetTireAngle());
	timeStamp = oldState.GetTimeStamp() + duration;

	//newState
	State newState;

	newState.SetHeading(heading);
	newState.SetXPos(xPos);
	newState.SetYPos(yPos);
	newState.SetTimeStamp(timeStamp);
	newState.SetTireAngle(tireAngle);

	_stateHistory.push_back(newState);

	return;


}

/**
 * Populates output file called _outputFileName with _stateHistory
 *
 * @requirement Each line in the output file should be formatted as follows:
 *
 * timestamp,x_pos,y_pos,tire_angle,heading
 *
 * All numbers are of type double.
 *
 * @requirement close the file when you are done.
 */
void CarSimulator::WriteStateHistoryToFile(){
	
	std::ofstream outputStream;

	outputStream.open(_outputFileName);

	if (!outputStream.is_open()) {
		cout << "output file not opened" << endl;
		return;
	}

	for (unsigned int i = 0; i < _stateHistory.size(); i++) {
		outputStream << _stateHistory[i].GetTimeStamp() << "," << _stateHistory[i].GetXPos() << "," << _stateHistory[i].GetYPos() << "," << _stateHistory[i].GetTireAngle() << "," << _stateHistory[i].GetHeading() << endl;
	}

	outputStream.close();

	return;





}

/**
 * Returns the most recent state to be used in RunCommand()
 *
 * @requirement if _stateHistory is empty, return default state (all data members are 0.0), otherwise return the last state in _stateHistory
 */
State CarSimulator::GetCurrentState(){
	if (_stateHistory.size() == 0) {
		return State(0.0, 0.0, 0.0, 0.0, 0.0);
	}
	else {
		return _stateHistory[_stateHistory.size()-1];
	}
}

