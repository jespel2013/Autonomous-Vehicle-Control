//----------------------------------------------------------------------//
// Author:
// Net ID:
// Date:
//
//----------------------------------------------------------------------//

#include "testEndToEnd.h"
#include "CarSimulator.h"

using namespace std;

void EndToEndTester::RunTests(){
    for(int i = 0; i < 10; i++){
        cout << "Running file test " << i << endl;
        TestFile(i);
    }
}


/*
 * @requirement pass if all lines output[testNum + 1] are the exact same (strcmp returns 0) as myOutput[testNum + 1] AND output files can be opened properly
 * @return pass: true, fail: false
 */
int EndToEndTester::TestFile(int testNum){
	double vel;
	double angle;
	double time; 

	ifstream inputStream;
	ifstream outputStream;
	ifstream myOutput;
    // create file paths for input, output, and myOutput
	stringstream inputFilePath;
	stringstream outputFilePath;
	stringstream myFilePath;

	inputFilePath << TEST_FILE_RELATIVE_PATH << "/input" << testNum + 1 << ".txt";
	outputFilePath << TEST_FILE_RELATIVE_PATH << "/output" << testNum + 1 << ".txt";
	myFilePath << TEST_FILE_RELATIVE_PATH << "/myoutput" << testNum + 1 << ".txt";
	
	inputStream.open(inputFilePath.str());
	//parse info
	inputStream >> vel >> angle >> time;
	Command newCommand(vel, angle, time);
    
    
    CarSimulator carSim(inputFilePath.str(), myFilePath.str());
    // Read Commands
	carSim.ReadCommandsFromFile();
    // run the commands
	carSim.RunAllCommands();
    // write to file
	carSim.WriteStateHistoryToFile();

	//testing file
	myOutput.open(myFilePath.str());
	outputStream.open(outputFilePath.str());

	if (!myOutput.is_open()) {
		cout << "ERROR: File not opened properly" << endl;
		return false;
	}

	string string1;
	string string2;
	while (!myOutput.eof()) {
		getline(myOutput, string1);
		getline(outputStream, string2);
		if (string1.compare(string2) != 0) {
			cout << "EndToEndTester Failed\n";
			return false;
		}
	}

    
    return true;
}
