//----------------------------------------------------------------------//
// Author:
// Net ID:
// Date:
//
//----------------------------------------------------------------------//

#include "testState.h"
#include "State.h"
#include <iostream>

using namespace std;

void StateTester::RunTests(){
    testSetTireAngleAboveMaximum();
    testSetTireAngleBelowMinimum();
    testSetHeadingAboveTwoPi();
    testSetHeadingBelowTwoPi();
}

/*
 * @requirement pass if _tire_angle returns is MAX_TIRE_ANGLE when SetTireAngle is provided an angle greater than MAX_TIRE_ANGLE
 * @return pass: true, fail: false
 */
bool StateTester::testSetTireAngleAboveMaximum(){
	State testState = State(1.0, 1.0, 1.0, 1.0, 1.0);

	testState.SetTireAngle(0.8);

	if (testState.GetTireAngle() == MAX_TIRE_ANGLE) {
		return true;
	}
        return false;
}

/*
 * @requirement pass if _tire_angle returns is MIN_TIRE_ANGLE when SetTireAngle is provided an angle less than MIN_TIRE_ANGLE
 * @return pass: true, fail: false
 */
bool StateTester::testSetTireAngleBelowMinimum(){
	State testState = State(1.0, 1.0, 1.0, 1.0, 1.0);

	testState.SetTireAngle(-0.8);

	if (testState.GetTireAngle() == MIN_TIRE_ANGLE) {
		return true;
	}
        return false;
}

/*
 * @requirement pass if _tire_angle returns an equivalent angle when SetHeading is provided an angle greater than than 2*pi
 * @return pass: true, fail: false
 */
bool StateTester::testSetHeadingAboveTwoPi(){
	State testState = State(1.0, 1.0, 1.0, 1.0, 1.0);

	testState.SetHeading(3 * M_PI);
	if (testState.GetHeading() == M_PI) {
		return true;
	}
        return false;
}

/*
 * @requirement pass if _tire_angle returns an equivalent angle when SetHeading is provided an angle less than than 2*pi
 * @return pass: true, fail: false
 */
bool StateTester::testSetHeadingBelowTwoPi(){
	State testState = State(1.0, 1.0, 1.0, 1.0, 1.0);
	testState.SetHeading(-M_PI);

	if (testState.GetHeading() == M_PI) {
		return true;
	}
        return false;
}
