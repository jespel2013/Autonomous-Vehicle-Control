//----------------------------------------------------------------------//
// Author:
// Net ID:
// Date:
//
//----------------------------------------------------------------------//

#include "testCommand.h"
#include "Command.h"
#include <iostream>

using namespace std;

void CommandTester::RunTests(){
    testNegativeVelocity();
    testVelocityTooHigh();
    testTireAngleTooLow();
    testTireAngleTooHigh();
    testNegativeTimeStamp();
}

/*
 * @requirement pass IsValid() returns false when all data members are valid except it has a negative velocity
 * @return pass: true, fail: false
 */
bool CommandTester::testNegativeVelocity() {
	double vel = -4.3;
	double angle = 0.50;
	double time = 2.34;

	Command testCommand = Command(vel, angle, time);

	if (!testCommand.IsValid()) {
		return true;
	}


    return false;
}

/*
 * @requirement pass IsValid() returns false when all data members are valid except it has a velocity above 30.0
 * @return pass: true, fail: false
 */
bool CommandTester::testVelocityTooHigh(){
	Command testCommand = Command(40.0, 0.50, 2.1);

	if (!testCommand.IsValid()) {
		return true;
	}
    return false;
}

/*
 * @requirement pass IsValid() returns false when all data members are valid except it has a tire_angle_rate below the range [0, 2*pi)
 * @return pass: true, fail: false
 */
bool CommandTester::testTireAngleTooLow(){
	Command testCommand = Command(20.0, -4.1, 2.1);

	if (!testCommand.IsValid()) {
		return true;
	}
    return false;
}

/*
 * @requirement pass IsValid() returns false when all data members are valid except it has a tire_angle_rate above the range [0, 2*pi)
 * @return pass: true, fail: false
 */
bool CommandTester::testTireAngleTooHigh(){
	Command testCommand = Command(20.0, 8.34, 2.1);

	if (!testCommand.IsValid()) {
		return true;
	}
    return false;
}

/*
 * @requirement pass IsValid() returns false when all data members are valid except it has a negative timestamp
 * @return pass: true, fail: false
 */
bool CommandTester::testNegativeTimeStamp(){
	Command testCommand = Command(20.0, 0.50, -2.1);

	if (!testCommand.IsValid()) {
		return true;
	}
    return false;
}
