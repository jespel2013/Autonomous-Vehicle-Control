//----------------------------------------------------------------------//
// Author:
// Net ID:
// Date:
//
//----------------------------------------------------------------------//

#include "CarSimulator.h"
#include <limits>

using namespace std;

/**
 * Creates CarSimulator object
 *
 * @requirement assigns _inputFileName to object data members _inputFileName
 * @requirement assigns _outputFileName to object data members _outputFileName
 */
CarSimulator::CarSimulator(std::string _inputFileName, std::string _outputFileName){

}

/**
 * Populates object _commands data member from _inputFileName
 *
 * @requirement if the Command IsValid() returns false for any Command, the input file is invalidated. An output file still needs to be generated
 * @requirement if a line is not formatted correctly, the file is not invalidated. It is just discarded.
 * @requirement close the file at the end of the function
 */
void CarSimulator::ReadCommandsFromFile(){
    return;
}

/**
 * Populates _stateHistory data member from already populated _commands by calling RunCommand on each command
 *
 * @requirement the last Command in _commands has a duration of .2 seconds
 * @requirement the calculated duration between each Command must be >= .005 seconds and <= .2 seconds otherwise, the whole set of _commands is invalidated. An output file should still be generated.
 */
void CarSimulator::RunAllCommands(){

}

/**
 * Adds a new State to _stateHistory given a Command and duration
 *
 * @requirement A new state is updated according to the following equations/pseudocode:
 *
 * x_pos = x_prev + duration*velocity*cos(tire_angle)*cos(heading)
 * y_pos = y_prev + duration*velocity*cos(tire_angle)*sin(heading)
 * tire_angle = tire_angle_prev + duration*tire_angle_rate
 * heading = heading_prev + duration*velocity*(1.0/L)*sin(tire_angle)
 * time_stamp = time_stamp_prev + duration
 *
 * @requirement all data members of the new State must be set with setters. Otherwise, bad things will happen.
 */
void CarSimulator::RunCommand( Command command, double duration ){

}

/**
 * Populates output file called _outputFileName with _stateHistory
 *
 * @requirement Each line in the output file should be formatted as follows:
 *
 * timestamp,x_pos,y_pos,tire_angle,heading
 *
 * All numbers are of type double.
 *
 * @requirement close the file when you are done.
 */
void CarSimulator::WriteStateHistoryToFile(){

}

/**
 * Returns the most recent state to be used in RunCommand()
 *
 * @requirement if _stateHistory is empty, return default state (all data members are 0.0), otherwise return the last state in _stateHistory
 */
State CarSimulator::GetCurrentState(){
    return State(0.0, 0.0, 0.0, 0.0, 0.0);
}

